import React, { useState } from 'react';

function App() {
  const [projectId, setProjectId] = useState('tokyo-house-454522-g7');
  const [replicaName, setReplicaName] = useState('database-replica-010');
  const [response, setResponse] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const checkReplica = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetch('http://localhost:3000/api/replicas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ projectId, replicaName }),
      });
      const data = await res.json();
      setResponse(data);
    } catch (err) {
      setError('Hubo un error al conectar con el backend');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const createReplica = () => {
    console.log('Crear nueva instancia (placeholder)');
    alert('Crear nueva instancia (placeholder)');
  };

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Verificador de Réplicas</h1>

      <div style={{ marginBottom: 10 }}>
        <label>Project ID: </label>
        <input
          type="text"
          value={projectId}
          onChange={(e) => setProjectId(e.target.value)}
        />
      </div>

      <div style={{ marginBottom: 10 }}>
        <label>Replica Name: </label>
        <input
          type="text"
          value={replicaName}
          onChange={(e) => setReplicaName(e.target.value)}
        />
      </div>

      <button onClick={checkReplica} disabled={loading}>
        {loading ? 'Verificando...' : 'Verificar réplica'}
      </button>

      <button onClick={createReplica} style={{ marginLeft: 10 }}>
        Crear nueva instancia
      </button>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {response && (
        <div style={{ marginTop: 20 }}>
          <h3>Respuesta del backend:</h3>
          <pre>{JSON.stringify(response, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}

export default App;